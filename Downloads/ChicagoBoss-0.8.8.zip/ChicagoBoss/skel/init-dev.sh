#!/usr/bin/env sh
#
# Chicago Boss Dev Init System
# easy start dev server (most common task)

cd `dirname $0`

./init.sh start-dev

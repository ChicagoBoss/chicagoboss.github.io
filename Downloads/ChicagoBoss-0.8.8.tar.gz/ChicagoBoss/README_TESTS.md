Introducing Common Tests to ChicagoBoss

For the longest time, ChicagoBoss had basically no testing of the entire framework.
We, Samuel Rose and Kai Janson, started to test this great framework and you can
contribute as well.

Fork the project, write Common Test tests that are not written yet, or fix tests
that are weak or bad, and then send us a pull request.


How to run tests:

At the command prompt, run

	$ ct_run -dir src/tests/ct -logdir src/tests/ct/results -suite <yourtestname>_SUITE 




